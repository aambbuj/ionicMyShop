import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SellProductPageRoutingModule } from './sell-product-routing.module';

import { SellProductPage } from './sell-product.page';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  imports: [
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    IonicModule,
    SellProductPageRoutingModule
  ],
  declarations: [SellProductPage]
})
export class SellProductPageModule {}
