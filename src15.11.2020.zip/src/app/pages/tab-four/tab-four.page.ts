import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-four',
  templateUrl: './tab-four.page.html',
  styleUrls: ['./tab-four.page.scss'],
})
export class TabFourPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
