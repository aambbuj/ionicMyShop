import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-three',
  templateUrl: './tab-three.page.html',
  styleUrls: ['./tab-three.page.scss'],
})
export class TabThreePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
