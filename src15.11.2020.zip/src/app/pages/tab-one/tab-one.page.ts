import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-one',
  templateUrl: './tab-one.page.html',
  styleUrls: ['./tab-one.page.scss'],
})
export class TabOnePage implements OnInit {

  constructor() { }
  showOrders(){
    console.log('orders page on')
  }
  ngOnInit() {
  }

}
